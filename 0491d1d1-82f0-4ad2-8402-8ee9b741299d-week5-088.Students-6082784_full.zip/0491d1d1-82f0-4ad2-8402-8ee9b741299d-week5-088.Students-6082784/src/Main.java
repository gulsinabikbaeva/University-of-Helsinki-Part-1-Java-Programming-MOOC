
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write here the main program
        Scanner reader= new Scanner(System.in);
        ArrayList<Student> list = new ArrayList<Student>();
        
        while (true) {
        System.out.println("name:");
        String name=reader.nextLine();
        if (name.equals("")) {
            break;
        }
        System.out.println("studentnumber:");
        String studentNumber=reader.nextLine();
        Student std = new Student(name, studentNumber);
        list.add(std);
        
        }
        
        for (Student std1 : list) {
        System.out.println(std1.toString());    
        }
        
        System.out.println("Give search term:");
        String nameS = reader.nextLine();
        System.out.println("Result:");
        for (Student std2 : list) {
            std2.containsChars(nameS);
        }
    }
}
