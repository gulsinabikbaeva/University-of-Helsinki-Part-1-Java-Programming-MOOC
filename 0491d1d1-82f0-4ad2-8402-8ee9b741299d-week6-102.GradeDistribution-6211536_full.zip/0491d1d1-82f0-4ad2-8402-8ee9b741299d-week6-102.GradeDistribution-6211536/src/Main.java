import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner lukija = new Scanner(System.in);
        System.out.println("Type exam scores, -1 completes:");
        ListOfClusters list = new ListOfClusters();
        Cluster cluster0 = new Cluster("0",0,0);
        Cluster cluster1 = new Cluster("1",0,0);
        Cluster cluster2 = new Cluster("2",0,0);
        Cluster cluster3 = new Cluster("3",0,0);
        Cluster cluster4 = new Cluster("4",0,0);
        Cluster cluster5 = new Cluster("5",0,0);
        list.addCluster(cluster0);
        list.addCluster(cluster1);
        list.addCluster(cluster2);
        list.addCluster(cluster3);
        list.addCluster(cluster4);
        list.addCluster(cluster5);
        int countAccepted=0;
        int countNotAccepted=0;
            while (true) {
            int a = Integer.parseInt(lukija.nextLine());
            if (a>0 && a<61) {
                Grade grade = new Grade(a);
                if(a<30) {
                    cluster0.addGrade(grade);
                    countNotAccepted++;
                } 
                else if (a>29 && a<35){
                    cluster1.addGrade(grade);
                    countAccepted++;
                    }
                else if (a>34 && a<40){
                    cluster2.addGrade(grade);
                    countAccepted++;
                    }
                else if (a>39 && a<45){
                    cluster3.addGrade(grade);
                    countAccepted++;
                }
                else if (a>44 && a<50){
                    cluster4.addGrade(grade);
                    countAccepted++;
                }
                else if (a>49 && a<61){
                    cluster5.addGrade(grade);
                    countAccepted++;
                }
            } else if (a>61) { 
                countNotAccepted++;
            }  
            if (a==-1){
                break;
            }
        }
        System.out.println("Grade distribution:");
        System.out.println(cluster5);
        System.out.println(cluster4);
        System.out.println(cluster3);
        System.out.println(cluster2);
        System.out.println(cluster1);
        System.out.println(cluster0);
        System.out.println("Acceptance average grade: "+list.average());
        System.out.println(countAccepted);
        System.out.println(countNotAccepted);
        if (countAccepted!=0) {
        System.out.println("Acceptance percentage: "+(double)(countAccepted*100/(countAccepted+countNotAccepted)));
        }
        System.out.println("Acceptance percentage: "+0.0);
        }
}

    

