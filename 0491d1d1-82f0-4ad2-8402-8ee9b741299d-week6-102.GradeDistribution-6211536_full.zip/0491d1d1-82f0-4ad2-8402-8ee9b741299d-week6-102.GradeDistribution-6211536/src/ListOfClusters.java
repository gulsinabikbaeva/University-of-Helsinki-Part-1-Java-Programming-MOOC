
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author gbikbaeva
 */
public class ListOfClusters {
    private ArrayList <Cluster> clusters=new ArrayList<Cluster>();
    private double percentage;
    private int totalGrades;
    private int totalCount;
    
    public ArrayList <Cluster> getClusters(){
        return this.clusters;
    }
    public double average(){
        for (Cluster cluster: clusters){
            totalGrades +=cluster.getTotal();
            totalCount +=cluster.getCount();
            percentage=(double)totalGrades/(double)totalCount;
        }
        return percentage;
    }
    
    public void addCluster(Cluster cluster){
        clusters.add(cluster);
    }
    
}
