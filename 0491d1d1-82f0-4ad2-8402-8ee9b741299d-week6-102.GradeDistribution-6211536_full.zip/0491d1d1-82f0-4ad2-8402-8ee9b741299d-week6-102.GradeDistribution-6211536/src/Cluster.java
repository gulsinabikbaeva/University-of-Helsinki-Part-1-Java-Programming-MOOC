
import java.util.ArrayList;
/**
 *
 * @author gbikbaeva
 */
public class Cluster {
    private String name;
    private int total;
    private int count;
    private ArrayList<Grade> grades=new ArrayList<Grade>();
    
    public Cluster(String name,int total, int count){
        this.name=name;
        this.total=total;
        this.count=count;
    }
    public void addGrade(Grade grade){
        grades.add(grade);
        total+=grade.getGrade();
        count++;
    }
    public String print(int count){
        String str="";
        for(int i=0; i<count; i++){
            str +="*";
        } return str;
    }
    public String toString(){
        return name+": "+print(count);
    }
    
    public int getTotal(){
        return total;
    }
    public int getCount(){
        return count;
    }
}
