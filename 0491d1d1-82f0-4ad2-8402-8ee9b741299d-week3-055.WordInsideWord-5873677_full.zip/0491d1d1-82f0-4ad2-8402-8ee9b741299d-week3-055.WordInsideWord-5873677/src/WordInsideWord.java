
import java.util.Scanner;

public class WordInsideWord {

    public static void indexOf(String text1, String text2) {
        
        if (text1.contains(text2)) {
            System.out.println("The word '"+text2+"' is found in the word '"+text1+"'.");
        } else {
            System.out.println("The word '"+text2+"' is not found in the word '"+text1+"'.");
        }
        
    }
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Type the first word:");
        String text1=reader.nextLine();
        System.out.println("Type the second word:");
        String text2=reader.nextLine();
        indexOf(text1, text2);
        
    }
}
