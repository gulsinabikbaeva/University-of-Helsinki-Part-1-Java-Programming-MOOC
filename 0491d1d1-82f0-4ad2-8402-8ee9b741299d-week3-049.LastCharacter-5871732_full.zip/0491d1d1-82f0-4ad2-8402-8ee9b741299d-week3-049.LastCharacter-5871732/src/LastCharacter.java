import java.util.Scanner;


public class LastCharacter {

public static char lastCharacter(String text) {
    int index = text.length();
    return text.charAt(index-1);
}
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Type your name:");
        String text = reader.nextLine();
        System.out.println("Last character: " + lastCharacter(text));
    }
}
