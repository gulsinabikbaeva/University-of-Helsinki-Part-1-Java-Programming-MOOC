import java.util.Scanner;

public class TheEndPart {
    
    public static void substring(String text, int a){
        System.out.print("Result: ");
        for (int i=text.length()-a; i<text.length(); i++ ) {
            System.out.print(text.charAt(i));
        }
    }
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Type a word:");
        String text =reader.nextLine();
        System.out.println("Length of the end part:");
        int a = Integer.parseInt(reader.nextLine());
        substring(text, a);
        System.out.println("");
    } 
}
