/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gbikbaeva
 */
public class BoundedCounter {
    private int value;
    private int limit;
    
    public BoundedCounter (int upperLimit){
        this.value=0;
        this.limit = upperLimit;
        
    }
    public void next() {
        if (value+1>limit) {
            value=0;
        } else value++;
    }
    public String toString() {
        if (value<10) {
            return "0"+value;
        } else return ""+value;
    }
    public int getValue(){
        return value;
    }
    public void setValue(int newValue) {
        if (newValue > 0 && newValue <= limit) {
        value = newValue;
       }
    }
}

 