public class PrintingOutText {

    public static void printText() {
        System.out.println("In the beginning there were the swamp, the hoe and Java.");
// Write your code here
    }

    public static void main(String[] args) {
        printText();
    }
}
