import java.util.Random;

public class PasswordRandomizer {
    // Define the variables
    final private int length;
    private Random random;
    private int number;
    

    public PasswordRandomizer(int length) {
        // Initialize the variable
        this.length=length;
        this.random=new Random();
    }

    public String createPassword() {
        // write code that returns a randomized password
        int i=0;
        String password="";
        while (i<length) {
            number=random.nextInt(26);
            char symbol = "abcdefghijklmnopqrstuvwxyz".charAt(number);
            password +=symbol;
            
            i++;
        } 
        
        return password;
    }
}
