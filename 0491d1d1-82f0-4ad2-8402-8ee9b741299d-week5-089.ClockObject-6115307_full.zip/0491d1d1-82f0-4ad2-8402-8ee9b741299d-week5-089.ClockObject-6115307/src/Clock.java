public class Clock {
    private BoundedCounter hours;
    private BoundedCounter minutes;
    private BoundedCounter seconds;
   
    public Clock(int hoursAtBeginning, int minutesAtBeginning, int secondsAtBeginning) {
        this.hours= new BoundedCounter(hoursAtBeginning,23);
        this.minutes= new BoundedCounter(minutesAtBeginning,59);
        this.seconds = new BoundedCounter(secondsAtBeginning,59);
    }
    
    public void tick() {
        seconds.tickV();
        if (seconds.getValue()==0) {
            minutes.tickV();
            if (minutes.getValue()==0) {
            hours.tickV();
        }
       }
    }
    public String toString() {
       return hours+":"+minutes+":"+seconds;
    }
}
