
public class BoundedCounter {
    private int value;
    private int limit;

    public BoundedCounter(int value, int limit) {
        this.value = value;
        this.limit = limit;
    }
    public void tickV() {
        if (value + 1 > limit) {
            value = 0;
        } else {
            value++;
        }
    }
    public String toString() {
        if (value < 10) {
            return "0" + value;
        } else {
            return "" + value;
        }
    }
    public int getValue() {
        return value;
    }
    public void setValue(int newValue) {
        if (newValue > 0 && newValue <= limit) {
            value = newValue;
        }
    }
}
