
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
/**
 *
 * @author gbikbaeva
 */
public class VehicleRegister {
    private HashMap<RegistrationPlate, String> owners;
    
    public VehicleRegister(){
        this.owners=new HashMap<RegistrationPlate, String>();
    }
    public String get(RegistrationPlate plate){
        if (plate.getRegCode()==null){
            return null;
        } else return owners.get(plate);
    }
    public boolean delete(RegistrationPlate plate){
        if (owners.containsKey(plate)) {
            owners.remove(plate);
            return true;
        }
        if (!owners.containsKey(plate)){
            return false;
        }
        return true;
    }
    public boolean add(RegistrationPlate plate, String owner){
        if (!owners.containsKey(plate)) {
            owners.put(plate, owner);
            return true;
        } else if (owners.containsKey(plate)){
            return false;
        }
        return true;
    }
    public void printRegistrationPlates(){
        for( RegistrationPlate plate : owners.keySet()) {
            System.out.println(plate);
        }
    }
    public void printOwners(){
        LinkedList<String> arr = new LinkedList<String>();
        for( String owner : owners.values()) {
            if(!arr.contains(owner)){
                arr.add(owner);
            } else continue;
        }
        for (String atr: arr) {
        System.out.println(atr);
        }
        arr.clear();
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + (this.owners != null ? this.owners.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final VehicleRegister other = (VehicleRegister) obj;
        if (this.owners != other.owners && (this.owners == null || !this.owners.equals(other.owners))) {
            return false;
        }
        return true;
    }
    
}
