
import java.lang.reflect.Array;
import java.util.Scanner;

public class SumOfThreeNumbers {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        int sum = 0;
       int[] read = new int[4];
       // store numbers read form user in this variable
       
       for (int i=1; i<4; i++) {
        System.out.println("Type the " + i + " number:");
        read[i] = Integer.parseInt(reader.nextLine());
        sum +=read[i];
       }


        // Write your program here
        // Use only variables sum and read

        System.out.println("Sum: " + sum);
    }
}
