
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author gbikbaeva
 */
public class Storehouse {
    private Map <String, Integer> list; //product-price
    private Map<String, Integer> stocks; // product-stock
    
    public Storehouse(){
        list = new HashMap <String, Integer>();
        stocks=new HashMap <String, Integer>();
    }
    public int stock(String product) {
        if (stocks.get(product)!=null) {
            return stocks.get(product); // stock
        } else return 0;
    }
    public Set<String> products(){
        Set<String> setNames = new HashSet<String>();
        for (String p : list.keySet()) {
            setNames.add(p);
        }
        return setNames;
    }
    public boolean take(String product) {
        if (stocks.get(product)!=null) {
        if (stocks.get(product)>0){
            int stock = stocks.get(product);
            stock--;
            stocks.put(product,stock);
            return true;
        }
        }
        return false; 
    }
    
    public void addProduct(String product, int price, int stock){
        list.put(product,price);
        stocks.put(product, stock);
    }
    public int price(String product){
        if (list.get(product)!=null) {
            return list.get(product);
        } else return -99;
    }
}

