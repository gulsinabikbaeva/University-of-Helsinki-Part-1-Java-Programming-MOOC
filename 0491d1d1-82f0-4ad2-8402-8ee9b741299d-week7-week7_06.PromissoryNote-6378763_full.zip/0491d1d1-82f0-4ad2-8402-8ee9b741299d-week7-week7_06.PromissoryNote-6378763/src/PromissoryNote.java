
import java.util.HashMap;

/**
 *
 * @author gbikbaeva
 */
public class PromissoryNote {
    private HashMap<String, Double> list;
    
    
    public PromissoryNote(){
        list= new HashMap<String, Double>();
    }
    public void setLoan(String toWhom, double value) {
        list.put(toWhom, value);
    }
    public double howMuchIsTheDebt(String whose){
        if (this.list.containsKey(whose)){
            return list.get(whose);
        }
        return 0;
    }
}
