
public class Main {

    public static void main(String[] args) {
        // Write your main program here. Implementing your own classes will be very useful.
        UserInterface ui = new UserInterface();
        ui.start();
 
    }
}
