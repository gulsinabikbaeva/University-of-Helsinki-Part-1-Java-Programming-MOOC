
import java.util.ArrayList;

/**
 *
 * @author gbikbaeva
 */
public class Box implements ToBeStored {
    private double maximumWeight;
    private ArrayList<ToBeStored> stored;
    
    public Box(double maximumWeight){
        this.maximumWeight=maximumWeight;
        this.stored= new ArrayList<ToBeStored>();
    }
    public int count(){
        int count=0;
        for (ToBeStored st : stored){
            count++;
        }
        return count;
    }
    
    public void add(ToBeStored t) {
       if (weight()+t.weight()<this.maximumWeight) {
        this.stored.add(t);
       }
    }
    
    public double weight() {
        double weight = 0;
        for (ToBeStored st : stored){
            weight +=st.weight();
        }
        return weight;
    }

    @Override
    public String toString() {
        return "Box: "+count()+" things, total weight "+ weight()+" kg";
    }
}
