
public class FromHundredToOne {

    public static void main(String[] args) {
for (int i=100; i>0; i--) {
    System.out.println(i);
}     
// Write your program here
    }
}
