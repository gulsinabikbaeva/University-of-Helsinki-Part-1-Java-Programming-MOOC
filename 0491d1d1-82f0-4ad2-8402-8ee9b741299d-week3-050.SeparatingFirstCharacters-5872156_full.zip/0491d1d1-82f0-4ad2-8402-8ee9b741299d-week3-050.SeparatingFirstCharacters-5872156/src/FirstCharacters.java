import java.util.Scanner;

public class FirstCharacters {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Type your name:");
        String text =reader.nextLine();
        
                  
        if (text.length()<2 ){
        System.out.println("");
        }  
        
        if (text.length()>2){
           
            for (int j=0; j<3; j++) {
           int b= j+1;
           System.out.println(b + ". character: " + text.charAt(j));
            }
        } 
        else System.out.println("");
        }
        
}
