
import java.util.Random;
/**
 *
 * @author gbikbaeva
 */
public class NightSky {
    private int count;
    private double density;
    private int width;
    private int height;
    
    public NightSky(double density, int width, int height){
        this.density=density;
        this.width=width;
        this.height=height;
    }
    public NightSky(double density) {
        this(density, 20,10);
    }
    public NightSky(int width, int height){
        this(0.1,width, height);
    }
    public void printLine() {
        Random random = new Random();
        for (int i = 0; i < width; i++) {
            if (random.nextDouble() < density) {
                System.out.print("*");
                count++;
            } else {
                System.out.print(" ");
            }
        }
        System.out.println();
        }
    public void print() {
        count = 0;
        for (int i = 0; i < height; i++) {
        printLine();
                }
    }

    public int starsInLastPrint(){
        return count;
    }
}
