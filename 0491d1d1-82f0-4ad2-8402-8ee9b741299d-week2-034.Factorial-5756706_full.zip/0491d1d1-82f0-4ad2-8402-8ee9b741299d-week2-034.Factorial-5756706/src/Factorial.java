import java.util.Scanner;

public class Factorial {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Type a number:");
        int a= Integer.parseInt(reader.nextLine());
        int tot=1; 
        for (int i=1; i<=a; i++) {
            tot = tot*i;
        }
        System.out.println("Factorial is " + tot);
    }
}
