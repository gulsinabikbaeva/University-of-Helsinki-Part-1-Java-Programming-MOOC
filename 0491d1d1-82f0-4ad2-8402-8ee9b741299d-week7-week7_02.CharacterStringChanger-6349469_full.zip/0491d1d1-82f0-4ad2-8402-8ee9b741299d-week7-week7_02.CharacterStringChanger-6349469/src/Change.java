/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gbikbaeva
 */
public class Change {
    private char toCharacter;
    private char fromCharacter;
    
    public Change(char fromCharacter, char toCharacter){
        this.fromCharacter=fromCharacter;
        this.toCharacter=toCharacter;
    }
            
     public String change(String characterString) {
        String newWord="";
         for (int i=0; i<characterString.length(); i++){
            if (characterString.charAt(i)==fromCharacter) {
                newWord +=toCharacter;
            } else {
                newWord +=characterString.charAt(i);
            }
         }
         return newWord;
     }
}
