
import java.util.ArrayList;


/**
 *
 * @author gbikbaeva
 */
public class Changer {
    private ArrayList<Change> changer=new ArrayList<Change>();
    public Changer(){
        
    }
    public void addChange(Change change) {
        changer.add(change);
    }
    public String change(String characterString){
        String word="";
        for (Change Change : changer){
            word=Change.change(characterString);
            characterString=word;
            }
         return word;
    }
    
}
