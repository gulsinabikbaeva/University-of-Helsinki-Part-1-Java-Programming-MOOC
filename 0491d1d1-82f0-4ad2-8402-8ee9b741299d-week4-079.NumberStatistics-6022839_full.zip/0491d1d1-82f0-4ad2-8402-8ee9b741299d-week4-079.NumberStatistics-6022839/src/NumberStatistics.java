
public class NumberStatistics {
    private int amountOfNumbers;
    private int tot;
    
    
    public NumberStatistics () {
        amountOfNumbers=0;
    }
    
    public void addNumber(int num){
        amountOfNumbers++;
        tot +=num;
          }
    public int amountOfNumbers(){
        return amountOfNumbers;
    }

    public int sum() {
        if (amountOfNumbers>0) {
        return tot;
        } else return 0;
        }
    
    public double average() {
        if (amountOfNumbers>0){
            return (double)sum()/(double)amountOfNumbers;
        } else return 0;
    }
}
