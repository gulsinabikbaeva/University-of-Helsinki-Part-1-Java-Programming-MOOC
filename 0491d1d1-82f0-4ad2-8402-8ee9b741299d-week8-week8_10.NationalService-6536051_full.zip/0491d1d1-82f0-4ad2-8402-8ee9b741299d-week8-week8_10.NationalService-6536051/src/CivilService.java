/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gbikbaeva
 */
public class CivilService implements NationalService {
    private int daysLeft; //362
    private int workingDays; //0
    
    public CivilService(){
        this.daysLeft=362;
    }

    @Override
    public int getDaysLeft() {
        return this.daysLeft;
    }
    @Override
    public void work() { 
          daysLeft--;
          workingDays++;
          if (daysLeft<0) {
              this.daysLeft=0;
          }
    }
    
}
