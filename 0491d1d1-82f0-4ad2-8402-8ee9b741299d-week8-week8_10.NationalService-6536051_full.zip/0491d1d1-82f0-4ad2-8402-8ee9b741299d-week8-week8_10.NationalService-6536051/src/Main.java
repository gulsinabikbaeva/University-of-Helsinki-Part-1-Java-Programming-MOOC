public class Main {
    public static void main(String[] args) {
        // Test your code here!
        MilitaryService v = new MilitaryService(180); 
        v.work(); 
        
        System.out.println(v.getDaysLeft());
    }
}
