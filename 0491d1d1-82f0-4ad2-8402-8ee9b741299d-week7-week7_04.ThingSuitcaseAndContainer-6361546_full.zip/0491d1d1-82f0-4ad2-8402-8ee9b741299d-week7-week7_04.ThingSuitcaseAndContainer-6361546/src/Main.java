
public class Main {

    public static void main(String[] args) {
        // use this main class to test your program!
        Container container = new Container(1000);
        addSuitcasesFullOfBricks(container);
        System.out.println(container);
    }

    public static void addSuitcasesFullOfBricks(Container container) {
        // adding 100 suitcases with one brick in each
            Thing thing=null;
            for(int j=1; j<101; j++) {
                thing = new Thing("brick", j);
                Suitcase suitcase= new Suitcase(100);
                suitcase.addThing(thing);
                container.addSuitcase(suitcase);
                
        }
    }

}
