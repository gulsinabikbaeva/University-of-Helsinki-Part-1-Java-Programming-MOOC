
import java.util.ArrayList;

/**
 *
 * @author gbikbaeva
 */
public class Container {
    private int maxWieght;
    private ArrayList<Suitcase> listC;
    private int sumC;
    
    public int getWeightC(){
        return sumC;
    }
    public Container(int maxWieght){
        this.maxWieght = maxWieght;
        this.listC=new ArrayList<Suitcase>();
        this.sumC=0;
    }
    public int getMaxWeight(){
        return maxWieght;
    }
    public void addSuitcase(Suitcase suitcase){
        int a=sumC+suitcase.totalWeight();
        if (a<=maxWieght){
            listC.add(suitcase);
            sumC +=suitcase.totalWeight();
        }
    }
    public String toString(){
        return listC.size()+" suitcases ("+sumC+" kg)";
    }
    public void printThings(){
        for(Suitcase suitcase: listC){
            suitcase.printThings();
            }
    }
    
}
