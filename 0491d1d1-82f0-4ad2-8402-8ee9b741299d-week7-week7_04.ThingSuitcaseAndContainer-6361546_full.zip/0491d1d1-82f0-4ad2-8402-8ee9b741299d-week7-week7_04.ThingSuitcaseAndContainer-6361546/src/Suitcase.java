
import java.util.ArrayList;

/**
 *
 * @author gbikbaeva
 */
public class Suitcase {
    private ArrayList<Thing> list;
    private int maxWeightLimit;
    
    public Suitcase(int maxWeightLimit){
        this.list=new ArrayList<Thing>();
        this.maxWeightLimit=maxWeightLimit;
        }
    public int getWeight(){
        return totalWeight();
    }
    public void addThing(Thing thing){
        int a=totalWeight()+thing.getWeight();
        if(a<=maxWeightLimit){
        list.add(thing);
        } 
    }
    public int totalWeight(){
        int totalWeight=0;
        for (Thing thing : list){
           totalWeight +=thing.getWeight();
        }
        return totalWeight;
    }
    public String toString(){
        if(totalWeight()==0){
            return "empty (0 kg)";
        } else if (list.size()==1) {
            return list.size()+" thing ("+totalWeight()+" kg)";
        } else {
            return list.size()+" things ("+totalWeight()+" kg)";
        }
    }
    public void printThings(){
        for(Thing thing:list){
            System.out.println(thing);
        }
    }
    
    public Thing heaviestThing(){
        Thing thing1=null;
        int heaviest=0;
        for( Thing thing: list){
            if (heaviest<thing.getWeight()){
                heaviest=thing.getWeight();
                thing1=thing;
            }
        }
        return thing1;
    }
}
