
public class Greatest {

    public static int greatest(int number1, int number2, int number3) {

        int result;
        int average =(number1+number2+number3)/3;
        
        if (average>=number1) {
            if (average>=number2) {
                result=number3;
            } else result=number2;
        } else result=number1;
            
        return result;
    }

    public static void main(String[] args) {
        int result = greatest(2, 7, 3);
        System.out.println("Greatest: " + result);
    }
}
