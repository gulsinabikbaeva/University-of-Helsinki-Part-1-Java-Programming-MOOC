
public class Counter {

    private static int value = 0;

    public static void increase() {
        value++;
    }

    public static int getValue() {
        return value;
    }
}
