
import java.util.Arrays;


public class Main {
    public static void main(String[] args) {
        // write testcode here
        
        int[] values = {8, 3, 7, 9, 1, 2, 4};
        sort(values);

        
    }
    public static void sort(int[] array) {
        for(int i=0; i<array.length; i++){
        System.out.println(Arrays.toString(array));
        int index=indexOfTheSmallestStartingFrom(array, i);
        swap(array, i, index);
        
    } 
    }
    public static int smallest(int[] values ){
        int smallest=values[0];
        for(int i=0; i<values.length; i++){
            if(smallest>values[i]){
                smallest=values[i];
            }
        }
        
        return smallest;
    }
    public static int indexOfTheSmallest(int[] values){
        int smallest=values[0];
        int a=0;
        for(int i=0;i<values.length; i++){
            if(smallest>values[i]){
                smallest=values[i];
                a=i;
            } 
        }
        return a;
    }
    public static int indexOfTheSmallestStartingFrom(int[] array, int index) {
    int smallest=array[index];
        int a=index;
        for(int i=index;i<array.length; i++){
            if(smallest>array[i]){
                smallest=array[i];
                a=i;
            } 
        }
        return a;
        }
    public static void swap(int[] array, int index1, int index2) {
        int temp=array[index1];
        array[index1]=array[index2];
        array[index2]=temp;
    }

}
