
import java.util.Scanner;

public class SeparatingCharacters {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Type your name:");
        String text = reader.nextLine();
        
        for (int k=0; k<text.length(); k++) {
            int i=k+1;
            System.out.println(i+". character: " + text.charAt(k));
        }
    }
}
