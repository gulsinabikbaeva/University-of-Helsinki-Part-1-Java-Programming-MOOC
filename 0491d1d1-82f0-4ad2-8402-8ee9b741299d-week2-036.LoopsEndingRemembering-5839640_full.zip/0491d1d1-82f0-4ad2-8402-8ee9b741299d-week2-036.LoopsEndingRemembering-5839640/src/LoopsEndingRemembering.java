import java.util.Arrays;
import java.util.Scanner;


public class LoopsEndingRemembering {
    
    public static void main(String[] args) {
       // int [] arr  = new int [10];
        
        int tot = 0;
        int count=0;
        double average=0.0;
        int countEven=0;
        int countOdd=0;
        
        Scanner reader = new Scanner(System.in);
        while (true) {
        System.out.println("Type number:");  
        int number =reader.nextInt();
        if (number<0 && number>-2) {
            System.out.println("Thank you and see you later!");
            break;
        }
        tot +=number;
        count++;
        if(number%2==0){
            countEven++;
        } else countOdd++;
        }
        average =1.0*tot/count;
        
        
        //for (int i=0; i<arr.length; i++) {
          //  int a = Integer.parseInt(reader.nextLine());
            
            //    if (a !=-1) {
                    
              //  arr [i]= a;
               // tot +=arr[i];
                //count++;
                //if (arr[i]%2==0) {
               //     countEven ++;
               // } else {
                //    countOdd ++;
                //}
                //}
                //else {
                //System.out.println("Thank you and see you later!");
                System.out.println("The sum is " + tot);
                System.out.println("How many numbers: " + count);
                //if (count !=0) {
                  //  double avr = (double)tot/ (double)count;
                    //System.out.println("Average: " + avr);
               // } else {
               System.out.println("Average: "+average);
                  //  System.out.println("Average: 0");
                //}
                System.out.println("Even numbers: " + countEven);
                System.out.println("Odd numbers: " + countOdd);
                //reader.close();
                //return;
                //}
}
}
//}

 
