
import java.util.Scanner;

public class LengthOfName {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        // call your method from here
        int count=0;
        System.out.println("Type your name:");
        String text = reader.nextLine();
        calculateCharacters(text);
        System.out.println("Number of characters: " + text.length());
    }
    
    // do here the method
    public static int calculateCharacters(String text){
        int count =text.length();
        return count;
    }
    
}
