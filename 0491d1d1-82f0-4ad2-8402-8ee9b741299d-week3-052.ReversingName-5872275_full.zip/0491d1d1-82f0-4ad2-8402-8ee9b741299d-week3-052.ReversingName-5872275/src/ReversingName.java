import java.util.Scanner;

public class ReversingName {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Type your name:");
        String text = reader.nextLine();
            System.out.print("In reverse order: ");      
            for (int index=text.length();index>0; index--) {
                System.out.print(text.charAt(index-1));
        }
            System.out.println("");
        }
    }

