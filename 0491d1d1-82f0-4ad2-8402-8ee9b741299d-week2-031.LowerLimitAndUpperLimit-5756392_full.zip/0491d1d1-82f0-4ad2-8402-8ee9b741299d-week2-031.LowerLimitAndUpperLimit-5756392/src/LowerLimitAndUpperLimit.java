
import java.util.Scanner;

public class LowerLimitAndUpperLimit {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("First numer:");
        int a =Integer.parseInt(reader.nextLine());
        System.out.println("Second numer:");
        int b =Integer.parseInt(reader.nextLine());
        
        if (a>b) {
            System.out.println("");
        } else {
            for (int i=a; i<b+1; i++) {
                System.out.println(i);
            }
        
        // write your code here

    }
}
}
