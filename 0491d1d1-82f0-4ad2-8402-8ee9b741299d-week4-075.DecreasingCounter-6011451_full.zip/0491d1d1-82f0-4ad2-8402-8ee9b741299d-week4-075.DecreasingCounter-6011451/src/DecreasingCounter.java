public class DecreasingCounter {
    private int value;
    private int temp;
// instance variable that remembers the value of the counter
    
    
    public DecreasingCounter(int valueAtStart) {
        temp=valueAtStart;
        this.value = valueAtStart;
    }

    public void printValue() {
        // do not touch this!
        System.out.println("value: " + value);
    }

    public void decrease() {
        // write here code to decrease counter value by one
        if (value>0) {
            value--;
        } else return;
    }

    // and here the rest of the methods
    public void setInitial()  {
       value=temp;
        
     }
    
    public void reset() {
        this.value=0;
    }
}
