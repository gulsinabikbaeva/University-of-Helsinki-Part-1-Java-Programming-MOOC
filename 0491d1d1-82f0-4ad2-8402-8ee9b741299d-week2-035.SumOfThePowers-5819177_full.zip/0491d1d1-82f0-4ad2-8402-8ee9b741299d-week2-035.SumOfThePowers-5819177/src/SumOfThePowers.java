
import java.util.Scanner;

public class SumOfThePowers {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.print("Type a number:");
        int a= Integer.parseInt(reader.nextLine());
        int tot=0;
        for (int i=0; i<=a; i++) {
            tot += (int)Math.pow(2,i);
            }
        System.out.println("totale: "+tot);
    }
}
