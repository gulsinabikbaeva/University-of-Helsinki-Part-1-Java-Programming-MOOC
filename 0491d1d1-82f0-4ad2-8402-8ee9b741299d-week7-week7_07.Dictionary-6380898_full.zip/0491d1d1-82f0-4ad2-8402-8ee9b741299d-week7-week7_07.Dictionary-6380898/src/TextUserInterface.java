
import java.util.Scanner;

/**
 *
 * @author gbikbaeva
 */
public class TextUserInterface {
    private Scanner reader;
    private Dictionary dictionary;
    
    public TextUserInterface(Scanner reader, Dictionary dictionary){
        this.reader=reader;
        this.dictionary=dictionary;
    }
    public void start(){
        System.out.println("Statement:");
        System.out.println("    add - adds a word pair to the dictionary");
        System.out.println("    translate - asks a word and prints its translation");
        System.out.println("    quit - quit the text user interface");
        while(true){
         System.out.print("Statement: ");
         String input=reader.nextLine();
         if (input.equals("quit")){
             break;
         }
         else if(input.equals("add")){
             System.out.println("In Finnish:");
             String inputF=reader.nextLine();
             System.out.println("Translation:");
             String inputT=reader.nextLine();
             dictionary.add(inputF, inputT);
         }
         else if(input.equals("translate")){
             System.out.print("Give a word:");
             String find=reader.nextLine();
             System.out.print("Translation:");
             System.out.println(dictionary.translate(find));
             }
         else {
             System.out.println("Unknown statement");
         }
     }
    }
}
