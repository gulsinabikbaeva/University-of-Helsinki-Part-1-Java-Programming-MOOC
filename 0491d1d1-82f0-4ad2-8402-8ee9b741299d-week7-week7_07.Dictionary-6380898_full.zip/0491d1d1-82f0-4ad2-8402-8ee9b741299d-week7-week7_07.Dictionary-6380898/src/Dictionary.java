
import java.util.ArrayList;
import java.util.HashMap;


/**
 *
 * @author gbikbaeva
 */
public class Dictionary {
    private HashMap<String, String> list;
    
    public Dictionary(){
        list=new HashMap<String, String>();
    }
    
    public String translate(String word){
        return list.get(word);
    }
    public void add(String word, String translation){
        list.put(word,translation);
    }
    public int amountOfWords(){
        return list.size();
    }
    public ArrayList<String> translationList(){
        ArrayList<String> newList= new ArrayList<String>();
        for(String key :list.keySet()){
            newList.add(key+" = "+list.get(key));
        }
        return newList;
    }
}
