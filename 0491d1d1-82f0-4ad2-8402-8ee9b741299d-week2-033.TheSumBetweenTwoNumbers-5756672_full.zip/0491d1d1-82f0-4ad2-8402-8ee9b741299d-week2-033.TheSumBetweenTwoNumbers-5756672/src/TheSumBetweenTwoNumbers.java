
import java.util.Scanner;


public class TheSumBetweenTwoNumbers {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("First number:");
        int a = Integer.parseInt(reader.nextLine());
        System.out.println("Second number:");
        int b = Integer.parseInt(reader.nextLine());
        int sum=0;
        for(int i=a; i<=b; i++) {
            sum += i;
        }
        System.out.println("Sum is " + sum);
    }
}
