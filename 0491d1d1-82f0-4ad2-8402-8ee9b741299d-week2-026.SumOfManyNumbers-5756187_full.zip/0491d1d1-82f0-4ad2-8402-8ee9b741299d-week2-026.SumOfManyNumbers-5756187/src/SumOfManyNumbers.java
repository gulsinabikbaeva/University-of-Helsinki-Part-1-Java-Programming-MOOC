
import java.util.Scanner;



public class SumOfManyNumbers {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        int sum = 0;
           
            int [] arr = new int[100];
            for (int i=0; i<arr.length; i++) {
            System.out.println("type a number:");
            arr[i] = Integer.parseInt(reader.nextLine());
                      
            sum+=arr[i]; 
            
            if (arr[i] == 0) {
                 break;
            }
            }
            
        System.out.println("Sum in the end: " + sum);
    }
}
