
import java.util.Scanner;

public class FirstPart {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Type a word:");
        String text = reader.nextLine();
        System.out.println("Length of the first part:");
        int a = Integer.parseInt(reader.nextLine());
        substring(text,a);
        
    }
    public static void substring(String text, int a) {
        System.out.print("Result: ");
        for(int i=0; i<a; i++) {
        System.out.print(text.charAt(i)); 
    }
        System.out.println("");
    }
}

